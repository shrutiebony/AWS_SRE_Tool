"""Load Jira and Confluence credentials from the environment or Secrets Manager."""

from __future__ import annotations

import json
import os


def secret_value(name: str, arn_name: str = "", arn: str = "") -> str:
    direct = os.environ.get(name, "")
    if direct:
        return direct
    secret_arn = arn or (os.environ.get(arn_name, "") if arn_name else "")
    if not secret_arn:
        return ""
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError

    try:
        response = boto3.client("secretsmanager", region_name=_region(secret_arn)).get_secret_value(SecretId=secret_arn)
    except (BotoCoreError, ClientError):
        return ""
    raw = response.get("SecretString") or ""
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return raw
    if not isinstance(parsed, dict):
        return raw
    return str(parsed.get(name) or parsed.get("token") or parsed.get("password") or parsed.get("api_token") or "")


def _region(arn: str) -> str | None:
    parts = arn.split(":")
    if len(parts) > 3 and parts[2] == "secretsmanager" and parts[3]:
        return parts[3]
    return None
